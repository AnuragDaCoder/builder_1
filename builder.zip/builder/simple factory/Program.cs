﻿// See https://aka.ms/new-console-template for more information


using builder;

var obj = new BikeFactory();
obj.CreateBike(new RoyalEnfield());
obj.ShowParts();