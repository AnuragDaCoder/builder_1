﻿namespace builder
{

    public class BikeFactory 
    {
        private BikeBuilder? _builder;
        public void CreateBike(BikeBuilder builder)
        {
            _builder = builder;
            _builder.BuildEngine();
        }

        public void ShowParts()
        {
            Console.WriteLine(_builder?.Bike.ToString());

        }
    }
   
}


