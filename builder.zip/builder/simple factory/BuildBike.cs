﻿namespace builder
{
    public abstract class BikeBuilder
    {
        public Bike Bike { get; set; }
        public BikeBuilder(string bikeType)
        {
            Bike = new Bike(bikeType);
        }
        public abstract void BuildEngine();

    }


    public class RoyalEnfield : BikeBuilder
    {
        public RoyalEnfield() : base("Enfield Powerful Engine")
        {

        }
        public override void BuildEngine()
        {
            Bike.AddPart("Enfiled Engine");
            Bike.AddPart("Enfiled Extra Part added");
        }

    }

    public class SplenderBike : BikeBuilder
    {
        public SplenderBike() : base("Splender Normal engine")
        {

        }
        public override void BuildEngine()
        {
            Bike.AddPart("Enfiled Engine");
        }
    }
}


