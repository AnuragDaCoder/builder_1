﻿namespace builder
{
    public class Bike
    {
        private string bikeType;
        private readonly List<string> parts = new();

        public Bike(string bikeType)
        {
            this.bikeType = bikeType;
        }

        public void AddPart(string part)
        {
            parts.Add(part);
        }

        public override string ToString()
        {
           return String.Join(Environment.NewLine,
                         parts.Select(x => String.Join(", ", x)));
        }
    }
    

}


